crawl to find all links related to each team contributed in firts their own country league  from 2015-2021

you can see the sample of one links in sample.jpg 